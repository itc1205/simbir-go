from setuptools import setup

setup(
    name="simbir_go", version="0.1205", packages=["simbir_go_backend"],
)