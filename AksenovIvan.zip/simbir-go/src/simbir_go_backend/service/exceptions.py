class AccountAlreadyExists(Exception):
    pass


class AccountNotFound(Exception):
    pass


class TransportNotFound(Exception):
    pass


class RentNotFound(Exception):
    pass


class UnrentableTransport(Exception):
    pass
